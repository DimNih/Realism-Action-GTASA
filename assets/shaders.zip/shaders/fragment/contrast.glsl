precision mediump float;

uniform sampler2D Diffuse;
varying mediump vec2 Out_Tex0;
uniform mediump vec3 ContrastMult;
uniform mediump vec3 ContrastAdd;
uniform mediump float VL_ScreenSize[2];
uniform mediump float VL_GlowX[4];
uniform mediump float VL_GlowY[4];
uniform mediump float VL_GlowRadiusX[4];
uniform mediump float VL_GlowRadiusY[4];
uniform mediump float VL_GlowAngle[4];
uniform mediump float VL_GlowPower[4];

void main() {
    vec4 source = texture2D(Diffuse, Out_Tex0);
    vec3 color = source.rgb * ContrastMult + ContrastAdd;

    // Surface-hit glow is composited over the original camera image. Its screen
    // footprint is derived from the ray hit normal and tangent in native code.
    vec2 fragmentPixel = gl_FragCoord.xy;
    vec3 headlightGlow = vec3(0.0);
    for (int i = 0; i < 4; ++i) {
        vec2 center = vec2(VL_GlowX[i], VL_ScreenSize[1] - VL_GlowY[i]);
        vec2 delta = fragmentPixel - center;
        float c = cos(VL_GlowAngle[i]);
        float s = sin(VL_GlowAngle[i]);
        delta = vec2(c * delta.x + s * delta.y,
                     -s * delta.x + c * delta.y);
        vec2 radius = max(vec2(VL_GlowRadiusX[i], VL_GlowRadiusY[i]), vec2(1.0));
        vec2 uv = delta / radius;
        float r2 = dot(uv, uv);
        float penumbra = exp(-r2 * 3.2) * (1.0 - smoothstep(0.20, 1.0, r2));
        headlightGlow += vec3(1.0, 0.78, 0.48) * (penumbra * VL_GlowPower[i]);
    }

    gl_FragColor = vec4(clamp(color + headlightGlow, 0.0, 1.0), source.a);
}